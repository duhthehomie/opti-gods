fx_version 'bodacious'
game 'gta5'

files {
    'timecycle_mods_1.xml'
}

data_file 'TIME_CYCLE_MOD_FILE' 'timecycle_mods_1.xml'
