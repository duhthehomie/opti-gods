fx_version 'cerulean'
game 'gta5'

description 'Opti Gods time freeze — locks in-game clock for stable FPS'
version '1.0.0'

client_scripts {
    'client.lua'
}